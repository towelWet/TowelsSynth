/*
 ==============================================================================
    Copyright (c) 2019-2022 Towels Finest Audio - Daniel Walz
    All rights reserved.

    License for non-commercial projects:

    Redistribution and use in source and binary forms, with or without modification,
    are permitted provided that the following conditions are met:
    1. Redistributions of source code must retain the above copyright notice, this
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice,
       this list of conditions and the following disclaimer in the documentation
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors
       may be used to endorse or promote products derived from this software without
       specific prior written permission.

    License for commercial products:

    To sell commercial products containing this module, you are required to buy a
    License from https://towelsfinest.com/developer/pluginguimagic/

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
    IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
    INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
    OF THE POSSIBILITY OF SUCH DAMAGE.
 ==============================================================================
 */

#include <stack>
#include <numeric>

#if TOWELS_ENABLE_BINARY_DATA
#include "BinaryData.h"
#endif

#include "General/towels_ApplicationSettings.cpp"
#include "General/towels_MagicGUIBuilder.cpp"
#include "General/towels_MagicPluginEditor.cpp"
#include "General/towels_MagicProcessor.cpp"
#include "General/towels_Resources.cpp"
#include "General/towels_MagicJUCEFactories.cpp"

#include "State/towels_MagicGUIState.cpp"
#include "State/towels_MagicProcessorState.cpp"
#include "State/towels_ParameterManager.cpp"
#include "State/towels_MidiParameterMapper.cpp"
#include "State/towels_RadioButtonManager.cpp"

#include "Layout/towels_GradientBackground.cpp"
#include "Layout/towels_Stylesheet.cpp"
#include "Layout/towels_Decorator.cpp"
#include "Layout/towels_Container.cpp"
#include "Layout/towels_GuiItem.cpp"
#include "Layout/towels_RootItem.cpp"

#include "Helpers/towels_DefaultGuiTrees.cpp"

#include "Visualisers/towels_MagicLevelSource.cpp"
#include "Visualisers/towels_MagicFilterPlot.cpp"
#include "Visualisers/towels_MagicAnalyser.cpp"
#include "Visualisers/towels_MagicOscilloscope.cpp"

#include "Widgets/towels_MagicLevelMeter.cpp"
#include "Widgets/towels_MagicPlotComponent.cpp"
#include "Widgets/towels_XYDragComponent.cpp"
#include "Widgets/towels_FileBrowserDialog.cpp"
#include "Widgets/towels_MidiLearnComponent.cpp"
#include "Widgets/towels_MidiDrumpadComponent.cpp"

#include "LookAndFeels/towels_JuceLookAndFeels.cpp"
#include "LookAndFeels/towels_LookAndFeel.cpp"
#include "LookAndFeels/towels_Skeuomorphic.cpp"

#if TOWELS_SHOW_GUI_EDITOR_PALLETTE

namespace EditorColours
{
    static juce::Colour background;
    static juce::Colour outline;
    static juce::Colour text;
    static juce::Colour disabledText;
    static juce::Colour removeButton;
    static juce::Colour selectedBackground;
}

#include "Editor/towels_ToolBox.cpp"
#include "Editor/towels_GUITreeEditor.cpp"
#include "Editor/towels_PropertiesEditor.cpp"
#include "Editor/towels_Palette.cpp"

#include "Editor/towels_MultiListPropertyComponent.cpp"
#include "Editor/towels_StylePropertyComponent.cpp"
#include "Editor/towels_StyleTextPropertyComponent.cpp"
#include "Editor/towels_StyleBoolPropertyComponent.cpp"
#include "Editor/towels_StyleColourPropertyComponent.cpp"
#include "Editor/towels_StyleGradientPropertyComponent.cpp"
#include "Editor/towels_StyleChoicePropertyComponent.cpp"

#endif // TOWELS_SHOW_GUI_EDITOR_PALLETTE
