/*
 ==============================================================================
    Copyright (c) 2019-2022 Towels Finest Audio - Daniel Walz
    All rights reserved.

    License for non-commercial projects:

    Redistribution and use in source and binary forms, with or without modification,
    are permitted provided that the following conditions are met:
    1. Redistributions of source code must retain the above copyright notice, this
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice,
       this list of conditions and the following disclaimer in the documentation
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors
       may be used to endorse or promote products derived from this software without
       specific prior written permission.

    License for commercial products:

    To sell commercial products containing this module, you are required to buy a
    License from https://towelsfinest.com/developer/pluginguimagic/

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
    IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
    INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
    OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
    OF THE POSSIBILITY OF SUCH DAMAGE.
 ==============================================================================

    BEGIN_JUCE_MODULE_DECLARATION

    ID:            towels_gui_magic
    vendor:        Towels Finest Audio
    version:       1.3.7
    name:          Towels GUI magic
    description:   This module allows to create GUI with a drag and drop editor
    dependencies:  juce_core, juce_audio_basics, juce_audio_devices, juce_audio_formats,
                   juce_audio_utils, juce_audio_processors, juce_gui_basics, juce_dsp,
                   juce_cryptography

    website:       https://towelsfinest.com/
    license:       Dual license: non commercial under BSD V2 3-clause

    END_JUCE_MODULE_DECLARATION

 ==============================================================================
 */

#pragma once

/** Config: TOWELS_SHOW_GUI_EDITOR_PALLETTE
            Enables the GUI editor palette allowing to edit the GUI. Ideally set this to 0 in a release build.
  */
#ifndef TOWELS_SHOW_GUI_EDITOR_PALLETTE
#define TOWELS_SHOW_GUI_EDITOR_PALLETTE 1
#endif

/** Config: TOWELS_ENABLE_BINARY_DATA
            Makes the binary resources available to the GUI. Make sure you actually have
            at least one file added, or this will fail to compile.
 */
#ifndef TOWELS_ENABLE_BINARY_DATA
#define TOWELS_ENABLE_BINARY_DATA 0
#endif

/** Config: TOWELS_ENABLE_OPEN_GL_CONTEXT
            If selected an juce OpenGLCOntext is attached. Not a big difference on OSX, but vital on Windows.
  */
#ifndef TOWELS_ENABLE_OPEN_GL_CONTEXT
#define TOWELS_ENABLE_OPEN_GL_CONTEXT 1
#endif


#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_devices/juce_audio_devices.h>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_cryptography/juce_cryptography.h>
#include <juce_dsp/juce_dsp.h>

#if JUCE_MODULE_AVAILABLE_juce_opengl && TOWELS_ENABLE_OPEN_GL_CONTEXT
#include <juce_opengl/juce_opengl.h>
#endif

#if JUCE_MODULE_AVAILABLE_juce_gui_extra
#include <juce_gui_extra/juce_gui_extra.h>
#endif

#include "General/towels_StringDefinitions.h"
#include "General/towels_ApplicationSettings.h"
#include "General/towels_SettableProperties.h"
#include "General/towels_Resources.h"

#include "Helpers/towels_ScopedInterProcessLock.h"
#include "Helpers/towels_PopupMenuHelper.h"
#include "Helpers/towels_MouseLambdas.h"
#include "Helpers/towels_ParameterAttachment.h"
#include "Helpers/towels_AtomicValueAttachment.h"
#include "Helpers/towels_Conversions.h"
#include "Helpers/towels_DefaultGuiTrees.h"

#include "Layout/towels_GradientBackground.h"
#include "Layout/towels_BoxModel.h"
#include "Layout/towels_Stylesheet.h"
#include "Layout/towels_Decorator.h"
#include "Layout/towels_GuiItem.h"
#include "Layout/towels_Container.h"
#include "Layout/towels_RootItem.h"

#include "LookAndFeels/towels_JuceLookAndFeels.h"
#include "LookAndFeels/towels_LookAndFeel.h"
#include "LookAndFeels/towels_Skeuomorphic.h"

#include "Visualisers/towels_MagicLevelSource.h"
#include "Visualisers/towels_MagicPlotSource.h"
#include "Visualisers/towels_MagicFilterPlot.h"
#include "Visualisers/towels_MagicAnalyser.h"
#include "Visualisers/towels_MagicOscilloscope.h"

#include "Widgets/towels_AutoOrientationSlider.h"
#include "Widgets/towels_MagicLevelMeter.h"
#include "Widgets/towels_MagicPlotComponent.h"
#include "Widgets/towels_XYDragComponent.h"
#include "Widgets/towels_FileBrowserDialog.h"
#include "Widgets/towels_MidiLearnComponent.h"
#include "Widgets/towels_MidiDrumpadComponent.h"

#include "State/towels_RadioButtonManager.h"
#include "State/towels_ParameterManager.h"
#include "State/towels_MidiParameterMapper.h"
#include "State/towels_MagicGUIState.h"
#include "State/towels_MagicProcessorState.h"

#include "General/towels_MagicGUIBuilder.h"
#include "General/towels_MagicPluginEditor.h"
#include "General/towels_MagicProcessor.h"
